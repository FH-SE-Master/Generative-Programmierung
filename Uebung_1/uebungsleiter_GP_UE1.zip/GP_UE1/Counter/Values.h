#ifndef Values_h
#define Values_h

template<int n>
struct IntValue {
	static const int value = n;
};

struct DoubleValue_0_5 {
	static const double value;
};
const double DoubleValue_0_5::value(0.5);

#endif