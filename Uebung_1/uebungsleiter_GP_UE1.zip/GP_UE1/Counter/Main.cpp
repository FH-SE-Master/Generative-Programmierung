#include <iostream>

#include "Values.h"
#include "Configurations.h"
#include "Counter.h"

using namespace std;

int main() {
	//typedef typename IntCounterConfig<IntValue<0>>::Counter Counter;
	typedef typename BoundedIntCounterConfig<IntValue<0>, IntValue<4>>::Counter Counter;
	Counter counter;

	cout << counter.value() << endl;
	counter.increment();
	counter.increment();
	counter.increment();
	counter.increment();
	counter.increment();
	counter.increment();
	counter.increment();
	counter.increment();
	cout << counter.value() << endl;
	counter.reset();
	cout << counter.value() << endl;

	return 0;
}