#include <iostream>
#include <chrono>

#include "Fibonacci.h"
#include "DO.h"

using namespace std;

template<typename Func>
void measure(Func func) {
	auto start = chrono::high_resolution_clock::now();
	func();
	auto end = chrono::high_resolution_clock::now();

	auto duration = chrono::duration_cast<chrono::duration<double>>(end - start);
	cout << "  // duration: " << fixed << duration.count() << endl;
}

int main() {
	static const int n = 40;
	//measure([&]() { cout << "fibonacci(" << n << ") = " << fibonacci(n) << endl; });
	//measure([&]() { cout << "Fibonacci<" << n << ">::RET = " << Fibonacci<n>::RET << endl; });

	measure([&]() {
		for (int i = 20; i <= 40; i++) {
			cout << "fibonacci(" << i << ") = " << fibonacci(i) << endl;
		}
	});

	measure([&]() {
		DO<FibonacciStatement<20>, FibonacciEndCondition<40>>::exec();
	});

	return 0;
}