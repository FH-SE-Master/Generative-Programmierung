#ifndef DO_h
#define DO_h

#include "IF.h"

struct Stop {
	static void exec() { }
};

template<typename Statement, typename Condition>
struct DO {
	typedef typename Statement::Next NewStatement;
	static void exec() {
		Statement::exec();

		// if condition == true
		//   exec new do
		// else
		//   stop

		IF<Condition::Code<NewStatement>::RET,
			DO<NewStatement, Condition>,
			Stop
		>::RET::exec();
	}
};

#endif