package tsp;

public interface Problem {
  public Solution CreateRandomSolution();
}