package tsp;

public class TSPParseException extends Exception {
  static final long serialVersionUID = 3141592653589793L;
  public TSPParseException(String message) {
    super(message);
  }
}